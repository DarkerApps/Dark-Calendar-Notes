<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Notes are stored only in browser localStorage via `src/lib/notes-storage.ts`; read it in effects/handlers, never during render — the app must work fully offline with no backend.
- No remote fonts, CDNs or network calls — the APK has no INTERNET permission (stripped in `android/app/src/main/AndroidManifest.xml`).
- `BUILD_TARGET=apk` (`bun run build:apk`) switches vite.config.ts to SPA mode without nitro, emitting a static `dist/client/index.html` that Capacitor (`capacitor.config.ts`, `android/`) wraps; normal builds stay unchanged.
- The `android/` Capacitor project is committed (theme, icon, permissions customised); `.github/workflows/android-apk.yml` builds the debug APK on push.
- Date keys are local `YYYY-MM-DD` strings; calendar weeks start on Sunday (`src/lib/calendar.ts`).
- The installable web app uses `vite-plugin-pwa` (generateSW, `/sw.js` written into `dist/client`, disabled for the APK build) with `public/manifest.json` and `public/icon-*.png`; the worker is registered only from `src/lib/pwa-register.ts`, which refuses dev, Lovable preview hosts, iframes, the Capacitor app and `?sw=off`.
