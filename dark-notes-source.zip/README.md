# Dark Notes

A pure black calendar for daily notes (milk, daily expenses, …). Tap a date to write; notes stay on your device. No internet, no permissions.

## Install as a web app (PWA)

Open the published site on your phone, then use **Add to Home screen** / **Install app** in the browser menu. After the first visit it opens and saves notes without internet. Add `?sw=off` to the URL to remove the offline copy.

## Get the Android APK

1. Connect this project to GitHub (Lovable → GitHub).
2. Every push to `main` runs **Build Dark Notes APK** under the repository's **Actions** tab.
3. Open the finished run and download **dark-notes-apk** — it contains `dark-notes.apk`.
4. Copy it to your phone and install it (allow "install unknown apps" for your file manager).

Push a tag such as `v1.0` to also attach the APK to a GitHub Release.

## Local commands

- `bun run dev` — run in the browser
- `bun run build:apk` — build the offline bundle into `dist/client`
- `bun run apk:sync` — build and copy it into `android/` (then open `android/` in Android Studio)
