import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.darknotes.app",
  appName: "Dark Notes",
  webDir: "dist/client",
  backgroundColor: "#000000",
  android: {
    backgroundColor: "#000000",
    allowMixedContent: false,
  },
};

export default config;
