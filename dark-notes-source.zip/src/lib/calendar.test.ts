import { beforeEach, describe, expect, it } from "vitest";

import { buildMonthGrid, parseDateKey, toDateKey } from "./calendar";
import { getDatesWithNotes, getNote, saveNote } from "./notes-storage";

describe("calendar", () => {
  it("starts weeks on Sunday and flags every Sunday", () => {
    // November 2026: the 1st is a Sunday.
    const grid = buildMonthGrid(2026, 10);
    expect(grid).toHaveLength(42);
    expect(grid[0]?.key).toBe("2026-11-01");
    const sundays = grid.filter((c) => c.sunday).map((c) => c.key);
    expect(sundays.slice(0, 5)).toEqual([
      "2026-11-01", "2026-11-08", "2026-11-15", "2026-11-22", "2026-11-29",
    ]);
    expect(grid[1]?.sunday).toBe(false);
  });

  it("rejects impossible dates", () => {
    expect(parseDateKey("2026-02-30")).toBeNull();
    expect(toDateKey(parseDateKey("2026-11-20")!)).toBe("2026-11-20");
  });
});

describe("notes storage", () => {
  beforeEach(() => window.localStorage.clear());

  it("saves a note per date in local storage", () => {
    saveNote("2026-11-20", "Milk 2L");
    expect(getNote("2026-11-20")).toBe("Milk 2L");
    expect(getNote("2026-11-21")).toBe("");
    expect(getDatesWithNotes().has("2026-11-20")).toBe(true);
  });

  it("removes the date when the note is cleared", () => {
    saveNote("2026-11-20", "Milk 2L");
    saveNote("2026-11-20", "   ");
    expect(getDatesWithNotes().has("2026-11-20")).toBe(false);
  });
});
