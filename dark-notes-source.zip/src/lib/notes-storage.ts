// Notes live only on the device, in localStorage. Call these from effects or
// event handlers, never during render (localStorage does not exist on the server).

const STORAGE_KEY = "dark-notes:v1";

type NotesMap = Record<string, string>;

function readAll(): NotesMap {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" ? (parsed as NotesMap) : {};
  } catch {
    return {};
  }
}

function writeAll(notes: NotesMap) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

export function getNote(dateKey: string): string {
  return readAll()[dateKey] ?? "";
}

/** Saves a note; an empty or whitespace-only note removes the date entirely. */
export function saveNote(dateKey: string, text: string) {
  const notes = readAll();
  if (text.trim() === "") delete notes[dateKey];
  else notes[dateKey] = text;
  writeAll(notes);
}

export function getDatesWithNotes(): Set<string> {
  return new Set(Object.keys(readAll()));
}
