import { describe, expect, it } from "vitest";


import { shouldRegisterServiceWorker } from "./pwa-register";

const prod = { prod: true, iframe: false, native: false };

describe("offline install worker", () => {
  it("registers on the published site", () => {
    expect(shouldRegisterServiceWorker("darkernotes.lovable.app", "", prod)).toBe(true);
  });
  it("never registers in the editor preview, dev, iframe, APK or with ?sw=off", () => {
    expect(shouldRegisterServiceWorker("id-preview--090c6699-0685-4744-9d65-649be9819e5a.lovable.app", "", prod)).toBe(false);
    expect(shouldRegisterServiceWorker("darkernotes.lovable.app", "", { ...prod, prod: false })).toBe(false);
    expect(shouldRegisterServiceWorker("darkernotes.lovable.app", "", { ...prod, iframe: true })).toBe(false);
    expect(shouldRegisterServiceWorker("darkernotes.lovable.app", "", { ...prod, native: true })).toBe(false);
    expect(shouldRegisterServiceWorker("darkernotes.lovable.app", "?sw=off", prod)).toBe(false);
  });
});
