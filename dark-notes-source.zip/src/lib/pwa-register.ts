/// <reference types="vite-plugin-pwa/client" />
// The only place the offline service worker is registered. It never runs in dev,
// in the Lovable editor preview, inside an iframe, or inside the Android APK.

const SW_PATH = "/sw.js";
const PROJECT_ID = "090c6699-0685-4744-9d65-649be9819e5a";
const PREVIEW_LABEL = /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/;
const LOVABLE_PREVIEW_DOMAINS = [".lovable.app", ".gpt-eng.com", ".gptengineer.run"];

function isPreviewHost(host: string): boolean {
  const label = host.split(".")[0] ?? "";
  for (const domain of LOVABLE_PREVIEW_DOMAINS) {
    if (!host.endsWith(domain)) continue;
    if (PREVIEW_LABEL.test(label)) return true;
    if (label === `project--${PROJECT_ID}-dev`) return true;
  }
  const exactOrSub = (d: string) => host === d || host.endsWith(`.${d}`);
  return exactOrSub("lovableproject.com") || exactOrSub("lovableproject-dev.com") || exactOrSub("beta.lovable.dev");
}

function inIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

function isNativeApp(): boolean {
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return Boolean(cap?.isNativePlatform?.());
}

async function unregisterAppWorkers() {
  if (!("serviceWorker" in navigator)) return;
  const regs = await navigator.serviceWorker.getRegistrations();
  await Promise.allSettled(
    regs
      .filter((r) => (r.active ?? r.installing ?? r.waiting)?.scriptURL.endsWith(SW_PATH))
      .map((r) => r.unregister()),
  );
}

export function shouldRegisterServiceWorker(host: string, search: string, opts: { prod: boolean; iframe: boolean; native: boolean }): boolean {
  if (!opts.prod || opts.iframe || opts.native) return false;
  if (new URLSearchParams(search).get("sw") === "off") return false;
  return !isPreviewHost(host.toLowerCase());
}

/** Call once from a client effect. */
export async function setupServiceWorker() {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
  const ok = shouldRegisterServiceWorker(window.location.hostname, window.location.search, {
    prod: import.meta.env.PROD,
    iframe: inIframe(),
    native: isNativeApp(),
  });
  if (!ok) {
    await unregisterAppWorkers();
    return;
  }
  const { registerSW } = await import("virtual:pwa-register");
  registerSW({ immediate: true });
}
