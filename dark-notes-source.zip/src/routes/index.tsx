import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import {
  buildMonthGrid,
  MONTHS,
  parseMonthKey,
  shiftMonth,
  toDateKey,
  toMonthKey,
  WEEKDAYS,
} from "@/lib/calendar";
import { getDatesWithNotes } from "@/lib/notes-storage";
import { cn } from "@/lib/utils";

type CalendarSearch = { m?: string };

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): CalendarSearch =>
    typeof search["m"] === "string" && parseMonthKey(search["m"]) ? { m: search["m"] } : {},
  head: () => ({
    meta: [
      { title: "Dark Notes — Calendar" },
      { name: "description", content: "Tap any date to write notes for milk, daily expenses and more." },
      { property: "og:title", content: "Dark Notes — Calendar" },
      { property: "og:description", content: "Tap any date to write notes for milk, daily expenses and more." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CalendarPage,
});

function CalendarPage() {
  const { m } = Route.useSearch();
  const navigate = useNavigate({ from: "/" });
  // Today and stored notes are device-local: read them after mount, not during SSR.
  const [todayKey, setTodayKey] = useState<string | null>(null);
  const [noted, setNoted] = useState<Set<string>>(new Set());
  const touchX = useRef<number | null>(null);

  useEffect(() => {
    setTodayKey(toDateKey(new Date()));
    setNoted(getDatesWithNotes());
  }, []);

  if (!todayKey) return <main className="min-h-dvh bg-background" />;

  const today = new Date();
  const view = (m ? parseMonthKey(m) : null) ?? { year: today.getFullYear(), month: today.getMonth() };
  const cells = buildMonthGrid(view.year, view.month);
  const isCurrentMonth = view.year === today.getFullYear() && view.month === today.getMonth();

  const go = (delta: number) => {
    const next = shiftMonth(view.year, view.month, delta);
    void navigate({ search: { m: toMonthKey(next.year, next.month) }, replace: true });
  };
  const goToday = () => void navigate({ search: {}, replace: true });

  return (
    <main
      className="mx-auto flex min-h-dvh max-w-md flex-col bg-background px-5 pb-[calc(env(safe-area-inset-bottom)+1.5rem)] pt-[calc(env(safe-area-inset-top)+2rem)] select-none"
      onTouchStart={(e) => (touchX.current = e.touches[0]?.clientX ?? null)}
      onTouchEnd={(e) => {
        const start = touchX.current;
        const end = e.changedTouches[0]?.clientX;
        touchX.current = null;
        if (start == null || end == null) return;
        const dx = end - start;
        if (Math.abs(dx) > 60) go(dx < 0 ? 1 : -1);
      }}
    >
      <header className="mb-8 flex items-center justify-between">
        <button
          type="button"
          onClick={() => go(-1)}
          aria-label="Previous month"
          className="flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors active:bg-muted"
        >
          <ChevronLeft className="size-5" strokeWidth={1.5} />
        </button>
        <button
          type="button"
          onClick={goToday}
          aria-label="Go to today"
          className="flex flex-col items-center"
        >
          <span className="text-xl font-light tracking-wide text-foreground">
            {MONTHS[view.month]}
          </span>
          <span
            className={cn(
              "text-xs tracking-[0.3em] text-muted-foreground",
              !isCurrentMonth && "underline decoration-faint underline-offset-4",
            )}
          >
            {view.year}
          </span>
        </button>
        <button
          type="button"
          onClick={() => go(1)}
          aria-label="Next month"
          className="flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors active:bg-muted"
        >
          <ChevronRight className="size-5" strokeWidth={1.5} />
        </button>
      </header>

      <div className="grid grid-cols-7 gap-y-1 text-center">
        {WEEKDAYS.map((d, i) => (
          <div
            key={d}
            className={cn(
              "pb-3 text-[0.65rem] font-medium uppercase tracking-widest",
              i === 0 ? "text-sunday" : "text-muted-foreground",
            )}
          >
            {d}
          </div>
        ))}

        {cells.map((cell) => {
          const isToday = cell.key === todayKey;
          return (
            <Link
              key={cell.key}
              to="/note/$date"
              params={{ date: cell.key }}
              aria-label={`Notes for ${cell.key}`}
              className="flex aspect-square items-center justify-center"
            >
              <span
                className={cn(
                  "relative flex size-11 items-center justify-center rounded-full text-base tabular-nums transition-colors active:bg-muted",
                  cell.inMonth
                    ? cell.sunday
                      ? "text-sunday"
                      : "text-foreground"
                    : cell.sunday
                      ? "text-sunday-dim"
                      : "text-faint",
                  isToday && "bg-today",
                )}
              >
                {cell.day}
                {noted.has(cell.key) && (
                  <span
                    className={cn(
                      "absolute bottom-1.5 size-1 rounded-full",
                      cell.inMonth ? "bg-muted-foreground" : "bg-faint",
                    )}
                  />
                )}
              </span>
            </Link>
          );
        })}
      </div>

      <footer className="mt-auto pt-10 text-center text-[0.65rem] uppercase tracking-[0.4em] text-faint">
        Dark Notes
      </footer>
    </main>
  );
}
