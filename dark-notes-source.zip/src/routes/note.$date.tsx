import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { formatLongDate, parseDateKey, toMonthKey } from "@/lib/calendar";
import { getNote, saveNote } from "@/lib/notes-storage";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/note/$date")({
  loader: ({ params }) => {
    const date = parseDateKey(params.date);
    if (!date) throw notFound();
    return { label: formatLongDate(date), month: toMonthKey(date.getFullYear(), date.getMonth()), sunday: date.getDay() === 0 };
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `${loaderData.label} — Dark Notes` : "Note — Dark Notes";
    const description = loaderData
      ? `Your notes for ${loaderData.label}.`
      : "Your notes for this day.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary" },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  component: NotePage,
});

function NotePage() {
  const { date } = Route.useParams();
  const { label, month, sunday } = Route.useLoaderData();
  const [text, setText] = useState<string | null>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const saved = getNote(date);
    setText(saved);
    if (!saved) requestAnimationFrame(() => areaRef.current?.focus());
  }, [date]);

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col bg-background px-5 pb-[calc(env(safe-area-inset-bottom)+1rem)] pt-[calc(env(safe-area-inset-top)+1.25rem)]">
      <header className="mb-6 flex items-center gap-2">
        <Link
          to="/"
          search={{ m: month }}
          aria-label="Back to calendar"
          className="-ml-2 flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors active:bg-muted"
        >
          <ChevronLeft className="size-5" strokeWidth={1.5} />
        </Link>
        <h1
          className={cn(
            "text-base font-light tracking-wide",
            sunday ? "text-sunday" : "text-foreground",
          )}
        >
          {label}
        </h1>
      </header>

      <textarea
        ref={areaRef}
        value={text ?? ""}
        disabled={text === null}
        onChange={(e) => {
          setText(e.target.value);
          saveNote(date, e.target.value);
        }}
        placeholder={"Milk 1L\nVegetables 120\n…"}
        spellCheck={false}
        aria-label={`Notes for ${label}`}
        className="flex-1 resize-none bg-transparent text-base leading-7 text-foreground caret-muted-foreground outline-none placeholder:text-faint"
      />
    </main>
  );
}
