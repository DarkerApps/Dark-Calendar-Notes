// Test-only stand-in for vite-plugin-pwa's virtual module.
export function registerSW() {
  return async () => {};
}
