// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// Never set ssr.external or resolve.external: the Worker has no runtime module resolution, so
// the build fails. Never add compression (compressPublicAssets, vite-plugin-compression):
// hosting already compresses at the edge.
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { VitePWA } from "vite-plugin-pwa";

// `BUILD_TARGET=apk vite build` produces a fully static, offline bundle (dist/client with
// index.html) that Capacitor wraps into the Android APK. Normal builds are unchanged.
const isApk = process.env["BUILD_TARGET"] === "apk";

// Installable, offline-capable web app. Registered only by src/lib/pwa-register.ts.
// Off for the APK build: the Android app already bundles everything locally.
const pwa = VitePWA({
  disable: isApk,
  registerType: "autoUpdate",
  injectRegister: null,
  manifest: false, // public/manifest.json is the manifest
  filename: "sw.js",
  // Write the worker next to the published site files, not the server bundle.
  outDir: "dist/client",
  devOptions: { enabled: false },
  workbox: {
    globPatterns: ["**/*.{js,css,png,ico,svg,json}"],
    // The calendar page itself is precached so the app opens offline right after install.
    additionalManifestEntries: [{ url: "/", revision: String(Date.now()) }],
    navigateFallback: null,
    cleanupOutdatedCaches: true,
    runtimeCaching: [
      {
        urlPattern: ({ request, url }) =>
          request.mode === "navigate" && !url.pathname.startsWith("/~oauth"),
        handler: "NetworkFirst",
        options: {
          cacheName: "dark-notes-pages",
          networkTimeoutSeconds: 3,
          precacheFallback: { fallbackURL: "/" },
        },
      },
      {
        urlPattern: ({ url, sameOrigin }) => sameOrigin && url.pathname.startsWith("/assets/"),
        handler: "CacheFirst",
        options: { cacheName: "dark-notes-assets" },
      },
    ],
  },
});

export default defineConfig({
  plugins: [pwa],
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
    ...(isApk ? { spa: { enabled: true, prerender: { outputPath: "/index.html" } } } : {}),
  },
  ...(isApk ? { nitro: false as const } : {}),
});
